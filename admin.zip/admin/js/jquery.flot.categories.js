(function($){var options={xaxis:{categories:null},yaxis:{categories:null}};function processRawData(plot,series,data,datapoints){var xCategories=series.xaxis.options.mode=="categories",yCategories=series.yaxis.options.mode=="categories";if(!(xCategories||yCategories))
return;var format=datapoints.format;if(!format){var s=series;format=[];format.push({x:true,number:true,required:true});format.push({y:true,number:true,required:true});if(s.bars.show||(s.lines.show&&s.lines.fill)){var autoscale=!!((s.bars.show&&s.bars.zero)||(s.lines.show&&s.lines.zero));format.push({y:true,number:true,required:false,defaultValue:0,autoscale:autoscale});if(s.bars.horizontal){delete format[format.length-1].y;format[format.length-1].x=true;}}
datapoints.format=format;}
for(var m=0;m<format.length;++m){if(format[m].x&&xCategories)
format[m].number=false;if(format[m].y&&yCategories)
format[m].number=false;}}
function getNextIndex(categories){var index=-1;for(var v in categories)
if(categories[v]>index)
index=categories[v];return index+1;}
function categoriesTickGenerator(axis){var res=[];for(var label in axis.categories){var v=axis.categories[label];if(v>=axis.min&&v<=axis.max)
res.push([v,label]);}
res.sort(function(a,b){return a[0]-b[0];});return res;}
function setupCategoriesForAxis(series,axis,datapoints){if(series[axis].options.mode!="categories")
return;if(!series[axis].categories){var c={},o=series[axis].options.categories||{};if($.isArray(o)){for(var i=0;i<o.length;++i)
c[o[i]]=i;}
else{for(var v in o)
c[v]=o[v];}
series[axis].categories=c;}
if(!series[axis].options.ticks)
series[axis].options.ticks=categoriesTickGenerator;transformPointsOnAxis(datapoints,axis,series[axis].categories);}
function transformPointsOnAxis(datapoints,axis,categories){var points=datapoints.points,ps=datapoints.pointsize,format=datapoints.format,formatColumn=axis.charAt(0),index=getNextIndex(categories);for(var i=0;i<points.length;i+=ps){if(points[i]==null)
continue;for(var m=0;m<ps;++m){var val=points[i+m];if(val==null||!format[m][formatColumn])
continue;if(!(val in categories)){categories[val]=index;++index;}
points[i+m]=categories[val];}}}
function processDatapoints(plot,series,datapoints){setupCategoriesForAxis(series,"xaxis",datapoints);setupCategoriesForAxis(series,"yaxis",datapoints);}
function init(plot){plot.hooks.processRawData.push(processRawData);plot.hooks.processDatapoints.push(processDatapoints);}
$.plot.plugins.push({init:init,options:options,name:'categories',version:'1.0'});})(jQuery);